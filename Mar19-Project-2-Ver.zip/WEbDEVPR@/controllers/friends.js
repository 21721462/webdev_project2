require('../models/db');
var mongoose = require('mongoose');
var Friend = mongoose.model('User');

//To accept request simply send reverse request
module.exports.sendRequest = function(req,res) {
	Friend.requestFriend({_id:req.current.id},{_id:req.friends.id},function(err){
		 if(err){
      console.log(err);
      res.status(500);
      res.render('error', {
        message:err.message,
        error: err
      });
    }
    else {
    	console.log(req.params.id, ' friend request sent');
   		}
	});
}

module.exports.removeUser = function(req,res){
	Friend.removeFriend({_id:req.current.id},{_id:req.friends.id}, function(err){  
		if(err)
		{
      console.log(err);
      res.status(500);
      res.render('error', {
        message:err.message,
        error: err
      });
  		}
  		else 
  		{
  			console.log(req.friend.id, ' Removed from Friends List');
  			//Return to friends list
  		}
	} )
}

module.exports.friendsList = function(req,res){
	Friend.getFriends({_id:req.current.id}, function(err, friendship){
		  if(err){
      console.log(err);
      res.status(500);
      res.render('error', {
        message:err.message,
        error: err
      });
    	}
    	else 
    	{
    		//Print out your friends. Maby access user rank and display by most simmirar ranks
    	}

	})
}

module.exports.findFriend = function(req,res){
	
}