Instructions to start the server
- Load up the node.js command prompt
- For windows, execute the line: set DEBUG=myapp:* & npm start
- For linux/mac, execute the line: DEBUG=myapp:* npm start
- Then load: http://localhost:3000/ in your browser
- To stop the server, press Ctrl+C in the command prompt
