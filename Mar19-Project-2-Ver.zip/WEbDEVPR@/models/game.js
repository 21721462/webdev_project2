var mongoose = require('mongoose');

var gameSchema = new mongoose.Schema(
{
	GameID: Number,
	GameName: String,
	GameImage: String,
	Desc : String 
	
});

mongoose.model('Game', gameSchema, 'games');