var router = require('express').Router();
var passport = require('passport');
var UserAcc = require('../models/account');

//Homepage with user logged it
router.get('/', function(req, res){
	res.render('login'{user: req.user});
})

router.get('/register', function(req,res){
	res.render('register', {});
})



router.post('/register', function(req,res){
	
})

module.exports = router;
