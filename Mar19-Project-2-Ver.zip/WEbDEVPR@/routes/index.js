var express = require('express');
var router = express.Router();
var mainController = require('../controllers/main');
var user = require('../models/account')
var passport = require('passport');

/* GET home page. */
router.get('/', mainController.index);

module.exports = router;

router.get('/login', passport.authenticate('steam'))

router.get('/login/steam',
	passport.authenticate('steam'), {failureRedirect: '/login'}),
	function(req,res){
		res.redirect('/');
	})

router.get('/login', passport.authenticate('local'), function(req,res) {
	res.redirect('/');
})

module.export = router; 